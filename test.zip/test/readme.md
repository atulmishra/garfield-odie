Sample project to download multiple files data from multiple locations.

Details about the application :-

1. Is a REST service accepting post request. Using SpringBoot to manage dependencies and to make as a singular easy to use micro service.
2. It supports different protocols to download files from , and is extensible to cater to any new protocol in future.
2. It downloads multiple files from different location in multi threaded way paralely.
3. Is an atomic operation either all the data is fetched and saved or none.
4. For large data files have used Java's FileChannel which will dirrectly map/sore data to output file from source. Will not load file data in memory.
5. Output files aare stored inside 'download' folder in project directory as of now. Inside download each file will be stored in its respective path.

*How to run*

1. The project is based in Maven/POM for dependency management.
2. Run mvn clean install
3. The service can be run as a direct java application by running class Application
4. Or can be run by command line also by executing java -jar target/test-agoda-problem-0.1.0.jar
5. Once it is running, just from Post client try to hit url "http"//localhost:8080/"
 sample post data : -
 {
   "fileDownloadedUrls": "http://www.act.org/content/dam/act/unsecured/documents/relaunch.pdf|http://www.act.org/content/dam/act/unsecured/documents/relaunch.pdf"
 }

6. You should get the final json response once the files are downloaded.
7. You can verify downloaded files inside 'downloaded' folder in project directory.

*TEST*
1. There is one test case in agoda.test.downloader.scheduler.testScheduleFilesDataDownLoad(). In which there is an actual http url
    is given for one file(you can change it). It will actually invoke the code and will download file.
 