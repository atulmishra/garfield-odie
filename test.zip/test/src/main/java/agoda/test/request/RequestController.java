package agoda.test.request;

import agoda.test.downloader.DataDownLoader;
import agoda.test.model.FilesDownloadRequest;
import agoda.test.model.FileDownloadResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
;

@RestController
public class RequestController {
    @Autowired
    DataDownLoader dataDownLoader;




    @RequestMapping(value ="/", method = RequestMethod.POST)
    public FileDownloadResponse downloadFiles(@RequestBody FilesDownloadRequest request) {
        // Get all the files urls pipe separated to start the downoad, currently expecting from http request but can read from property file as well
        //fileUrlsPipeSeparated="sftp://test.com";
        return dataDownLoader.downloadFilesContentFromUrls(request.getFileDownloadedUrls());
    }
    
}
