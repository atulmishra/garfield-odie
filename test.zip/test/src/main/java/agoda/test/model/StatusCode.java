package agoda.test.model;

/**
 * Created by Divya on 8/7/2018.
 */
public enum StatusCode {
    SUCCESS(1),
    ERROR(2);
    private int statusCode;

    StatusCode(int statusCode) {
        this.statusCode = statusCode;
    }

    public int getStatusCode() {
        return statusCode;
    }
}
