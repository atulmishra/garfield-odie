package agoda.test.model;

/**
 * Created by Divya on 8/5/2018.
 */
public class FileDownloadResponse {

    private String messageString;
    private int statusCode;

    public String getMessageString() {
        return messageString;
    }

    public void setMessageString(String messageString) {
        this.messageString = messageString;
    }

    public int getStatusCode() {
        return statusCode;
    }

    public void setStatusCode(int statusCode) {
        this.statusCode = statusCode;
    }

    public static FileDownloadResponse giveDefaultResponse(){
        FileDownloadResponse response = new FileDownloadResponse();
        response.setMessageString("SUCCESS");
        response.setStatusCode(StatusCode.SUCCESS.getStatusCode());
        return response;
    }
}
