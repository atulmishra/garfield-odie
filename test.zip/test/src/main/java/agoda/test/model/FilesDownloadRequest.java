package agoda.test.model;


public class FilesDownloadRequest {
    private String fileDownloadedUrls;

    public String getFileDownloadedUrls() {
        return fileDownloadedUrls;
    }

    public void setFileDownloadedUrls(String fileDownloadedUrls) {
        this.fileDownloadedUrls = fileDownloadedUrls;
    }
}
