package agoda.test.model;


public class FileToDownload {
    private String fileUrlToBeDownloaded;
    private ProtocolType protocolType;
    private String outputFilePath;

    public FileToDownload(String fileUrlToBeDownloaded, ProtocolType protocolType, String outputFilePath) {
        this.fileUrlToBeDownloaded = fileUrlToBeDownloaded;
        this.protocolType = protocolType;
        this.outputFilePath = outputFilePath;
    }

    public String getFileUrlToBeDownloaded() {
        return fileUrlToBeDownloaded;
    }

    public ProtocolType getProtocolType() {
        return protocolType;
    }

    public String getOutputFilePath() {
        return outputFilePath;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        FileToDownload that = (FileToDownload) o;

        if (fileUrlToBeDownloaded != null ? !fileUrlToBeDownloaded.equals(that.fileUrlToBeDownloaded) : that.fileUrlToBeDownloaded != null)
            return false;
        return protocolType == that.protocolType;

    }

    @Override
    public int hashCode() {
        int result = fileUrlToBeDownloaded != null ? fileUrlToBeDownloaded.hashCode() : 0;
        result = 31 * result + (protocolType != null ? protocolType.hashCode() : 0);
        return result;
    }
}
