package agoda.test.model;

/**
 * Created by Divya on 8/5/2018.
 */
public enum ProtocolType {
    HTTP("http"),
    HTTPS("https"),
    FTP("ftp"),
    SFTP("sftp");
    private String protocolName;

    ProtocolType(String protocolName) {
        this.protocolName = protocolName;
    }

    public static ProtocolType getProtocolTypeFromName(String name){
        switch (name){
            case "http":return ProtocolType.HTTP;
            case "https":return ProtocolType.HTTPS;
            case "ftp":return ProtocolType.FTP;
            case "sftp":return ProtocolType.SFTP;
        }
        return null;
    }
}
