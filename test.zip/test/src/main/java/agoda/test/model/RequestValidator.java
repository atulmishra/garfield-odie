package agoda.test.model;

import agoda.test.exception.FileUrlValidationException;
import org.springframework.util.StringUtils;

import java.util.List;

/**
 * Created by Divya on 8/5/2018.
 */
public class RequestValidator {

    public static final int FAILURE=2;
    public static final int SUCCESS=1;
    public static FileDownloadResponse validateEmptyNullFileUrls(String fileUrls){
        FileDownloadResponse response=new FileDownloadResponse();
        response.setMessageString("SUCCESS");
        response.setStatusCode(SUCCESS);
        if(StringUtils.isEmpty(fileUrls)){
            response.setMessageString("Please provide full url of file(s) to download the data.");
            response.setStatusCode(FAILURE);
            return response;
        }
        return response;
    }

    public static void validateFileUrls(List<String> fileUrls) throws FileUrlValidationException {
        for(String fileUrl:fileUrls){
            int hostIndex=fileUrl.indexOf("://");
            if(hostIndex <0){
                throw new FileUrlValidationException("Invalid file url for: "+fileUrl);
            }
            //Validating if hostname is given after ://
            if(hostIndex+3 >= fileUrl.length()){
                throw new FileUrlValidationException("No proper host given for: "+fileUrl);
            }
            int colonIndex=fileUrl.indexOf(":");
            String protocol = fileUrl.substring(0,colonIndex);
            if(StringUtils.isEmpty(protocol) || ProtocolType.getProtocolTypeFromName(protocol) == null){
                throw new FileUrlValidationException("Invalid file protocol: "+protocol);
            }
        }
    }
}
