package agoda.test.exception;

/**
 * Created by Divya on 8/5/2018.
 */
public class FileUrlValidationException extends Exception{
    public FileUrlValidationException(String message) {
        super(message);
    }
}
