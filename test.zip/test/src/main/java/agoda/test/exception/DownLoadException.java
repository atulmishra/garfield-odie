package agoda.test.exception;

/**
 * Created by Divya on 8/5/2018.
 */
public class DownLoadException extends Exception{
    public DownLoadException(String message) {
        super(message);
    }
}
