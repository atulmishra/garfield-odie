package agoda.test.downloader;

import agoda.test.exception.FileUrlValidationException;
import agoda.test.model.FileToDownload;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.FileOutputStream;
import java.io.IOException;
import java.net.URL;
import java.nio.channels.Channels;
import java.nio.channels.FileChannel;
import java.nio.channels.ReadableByteChannel;


public class SFTPFileDataDownloader extends FileDownloader{

    Logger logger = LoggerFactory.getLogger(SFTPFileDataDownloader.class);
   private FileToDownload fileToDownload;

    public SFTPFileDataDownloader(FileToDownload fileToDownload) {
        this.fileToDownload = fileToDownload;
    }

    @Override
    public void processData() throws IOException, FileUrlValidationException {
        String outputFilePath = fileToDownload.getOutputFilePath();
        String fileDownloadUrl = fileToDownload.getFileUrlToBeDownloaded();
        try {

            //This will return URL based on the protcol
            URL url = new URL(fileDownloadUrl);
            ReadableByteChannel readableByteChannel = Channels.newChannel(url.openStream());
            FileOutputStream fileOutputStream = new FileOutputStream(outputFilePath);
            FileChannel fileChannel = fileOutputStream.getChannel();
            //Using file channel which will directly transfer file from URL to the output File.
            //This will not load the file/byte in memory, but will directly transfer file content from URL to output file
            fileChannel.transferFrom(readableByteChannel, 0, Long.MAX_VALUE);
        }
        catch (Exception ex)
        {
            logger.error("Could not process/download file data: {}",ex.getMessage());
            throw new FileUrlValidationException("Could not process/download data,ex: "+ex.getMessage());
        }
    }
    @Override
    public FileToDownload getFileToDownLoad() {
        return fileToDownload;
    }
}
