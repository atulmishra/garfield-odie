package agoda.test.downloader;

import agoda.test.model.FileToDownload;
import org.springframework.stereotype.Component;

@Component
public class FileDownloaderFactory {



    public FileDownloader getFileDownloader(FileToDownload fileToDownload){

        switch (fileToDownload.getProtocolType()){
            case HTTP:
            case HTTPS:return new HTTPFileDataDownloader(fileToDownload);
            case FTP:return new FTPFileDataDownloader(fileToDownload);
            case SFTP:return new SFTPFileDataDownloader(fileToDownload);
            default:return null;
        }
    }
}
