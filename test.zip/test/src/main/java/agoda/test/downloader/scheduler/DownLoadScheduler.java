package agoda.test.downloader.scheduler;

import agoda.test.downloader.FileDownloader;
import agoda.test.model.FileToDownload;
import agoda.test.model.FileDownloadResponse;
import agoda.test.model.StatusCode;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.util.Set;
import java.util.concurrent.*;

@Component
public class DownLoadScheduler {

    Logger logger = LoggerFactory.getLogger(DownLoadScheduler.class);

    //Schedule all the files to be downloaded by multiple threads parallely
    public FileDownloadResponse scheduleFilesDataDownLoad(Set<FileDownloader> fileDownloaders){
        FileDownloadResponse response=new FileDownloadResponse();
        response.setStatusCode(StatusCode.SUCCESS.getStatusCode());
        final ExecutorService threadPool = Executors.newFixedThreadPool(5);
        final ExecutorCompletionService<FileToDownload> completionService = new ExecutorCompletionService<>(threadPool);
        for(FileDownloader fileDownloader:fileDownloaders){
            DownloadTask downloadTask=new DownloadTask(fileDownloader);
            completionService.submit(downloadTask);
        }
        // Will check parallel processing and in case of any exception, shutdown the running executor service and
        // just clear all the files data written so far like Transaction
        for(FileDownloader fileDownloader:fileDownloaders){
            FileToDownload future;
            try {
                future=completionService.take().get();
                logger.info("Completed downloading of file with output: {}",future.getOutputFilePath());
            } catch (Exception exception) {
                logger.error("Could not write/download file: {}",exception);
                response.setMessageString("Could not download the data from all files: "+exception.getMessage());
                // Shutdown and clean any existing task and files.
                processException(fileDownloaders,threadPool,response);
            }

        }
        return response;
    }

    private void processException(Set<FileDownloader> fileDownloaders, ExecutorService completionService, FileDownloadResponse response) {
        //Shut down any existing service and clear the files written so far
        completionService.shutdown();
        response.setStatusCode(StatusCode.SUCCESS.getStatusCode());
        for(FileDownloader fileDownloader:fileDownloaders){
            fileDownloader.cleanPartialDataIfWritten();
        }
    }


}
