package agoda.test.downloader.scheduler;

import agoda.test.downloader.FileDownloader;
import agoda.test.exception.DownLoadException;

import java.util.concurrent.Callable;

//Callable task which will actually invoke the file downloading processing
public class DownloadTask implements Callable{

    private FileDownloader fileDownloader;

    public DownloadTask(FileDownloader fileDownloader) {
        this.fileDownloader = fileDownloader;
    }

    @Override
    public Object call() throws Exception {
        try{
            fileDownloader.processData();
        }
        catch(Exception ex){
            //Log the error
            throw new DownLoadException("Data download exception: "+ex.getMessage());

        }
        return fileDownloader.getFileToDownLoad();
    }
}
