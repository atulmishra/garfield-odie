package agoda.test.downloader.converter;

import agoda.test.exception.FileUrlValidationException;
import agoda.test.model.FileToDownload;
import agoda.test.model.ProtocolType;
import agoda.test.model.RequestValidator;
import agoda.test.model.FileDownloadResponse;
import org.springframework.stereotype.Component;

import java.util.*;

@Component
public class UrlsToFileCreator {

    public Set<FileToDownload> createFiles(String fileurls) throws FileUrlValidationException {
        Set<FileToDownload> fileToDownloads = new HashSet<>();
        FileDownloadResponse response= RequestValidator.validateEmptyNullFileUrls(fileurls);
        if(RequestValidator.SUCCESS == response.getStatusCode()){
            List<String> seperatedFileUrls=new ArrayList();
            if(fileurls.indexOf("|") > -1){
                String[] fileArray = fileurls.split("\\|");
                seperatedFileUrls = Arrays.asList(fileArray);
            }
            else{
                seperatedFileUrls.add(fileurls);
            }
            RequestValidator.validateFileUrls(seperatedFileUrls);
            for(String fileUrl:seperatedFileUrls){
                FileToDownload fileToDownload=new FileToDownload(getDownloadUrlPathForFile(fileUrl),getProtocolType(fileUrl),getOutPutFilePath(fileUrl));
                fileToDownloads.add(fileToDownload);
            }

        }

        return fileToDownloads;
    }

    private ProtocolType getProtocolType(String fileUrl){
        int colonIndex=fileUrl.indexOf(":");
        String protocol = fileUrl.substring(0,colonIndex);
        return ProtocolType.getProtocolTypeFromName(protocol);
    }

    private String getOutPutFilePath(String fileUrl){
        String downloadedDirectory="downloaded/";
        int hostIndex=fileUrl.indexOf("://");
        int pathLength=fileUrl.length();
        String outPutFilePath = fileUrl.substring(hostIndex+3,pathLength);
        return downloadedDirectory+outPutFilePath;
    }

    private String getDownloadUrlPathForFile(String fileUrl){
        return fileUrl;
    }


}
