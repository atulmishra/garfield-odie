package agoda.test.downloader;

import agoda.test.downloader.scheduler.DownLoadScheduler;
import agoda.test.exception.FileUrlValidationException;
import agoda.test.model.FileToDownload;
import agoda.test.model.FileDownloadResponse;
import agoda.test.downloader.converter.UrlsToFileCreator;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.HashSet;
import java.util.Set;

@Component
public class DataDownLoader {

    Logger logger = LoggerFactory.getLogger(DataDownLoader.class);

    @Autowired
    UrlsToFileCreator urlsToFileCreator;

    @Autowired
    FileDownloaderFactory fileDownloaderFactory;

    @Autowired
    DownLoadScheduler downLoadScheduler;

    public FileDownloadResponse downloadFilesContentFromUrls(String fileUrlsToDownload)
    {
        logger.info("Started downloading files with urls: {}",fileUrlsToDownload);
        FileDownloadResponse response = FileDownloadResponse.giveDefaultResponse();
        Set<FileToDownload> fileToDownloads =new HashSet<>();
        Set<FileDownloader> fileDownloaders =new HashSet<>();
        try{
            //Creating FileToDownload Models from the pipe separated urls.
            fileToDownloads=urlsToFileCreator.createFiles(fileUrlsToDownload);

            //Get respective/specific Downloader according to Protocol Type.
            fileDownloaders=getFileDownLoaders(fileToDownloads);

            //Invoking Scheduler to submit multiple tasks for the file download.
            response=downLoadScheduler.scheduleFilesDataDownLoad(fileDownloaders);
        }
        catch(FileUrlValidationException exception){
            logger.error("FileUrls validation fails, Exception: {}",exception.getMessage());
            response.setMessageString("FileUrls validation fails, Exception: "+exception.getMessage());
            response.setStatusCode(2);
            return response;
        }
        catch(Exception ex){
            logger.error("FileUrls downloading fails, Exception: {}",ex.getMessage());
            response.setMessageString("FileUrls downloading fails, Exception: "+ex.getMessage());
            response.setStatusCode(2);
            return response;
        }
        return response;
    }

    private Set<FileDownloader>  getFileDownLoaders(Set<FileToDownload> fileToDownloads) throws FileUrlValidationException {
        Set<FileDownloader> fileDownloaders = new HashSet<>();
        for(FileToDownload fileToDownload:fileToDownloads){
            FileDownloader fileDownloader = fileDownloaderFactory.getFileDownloader(fileToDownload);
            if(fileDownloader == null){
                throw new FileUrlValidationException("Could not process/download data, no valid downloading protocol");
            }
            fileDownloaders.add(fileDownloader);
        }
        return fileDownloaders;
    }
}
