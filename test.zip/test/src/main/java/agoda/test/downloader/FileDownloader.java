package agoda.test.downloader;

import agoda.test.downloader.scheduler.DownLoadScheduler;
import agoda.test.exception.FileUrlValidationException;
import agoda.test.model.FileToDownload;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.nio.file.DirectoryNotEmptyException;
import java.nio.file.Files;
import java.nio.file.NoSuchFileException;
import java.nio.file.Paths;

/**
 * Created by Divya on 8/5/2018.
 */
public abstract class FileDownloader {

    Logger logger = LoggerFactory.getLogger(FileDownloader.class);

    protected FileToDownload fileToDownload;
    public abstract void processData() throws IOException, FileUrlValidationException;
    public abstract FileToDownload getFileToDownLoad();
    public void cleanPartialDataIfWritten(){
        try
        {
            String outputFilePath = getFileToDownLoad().getOutputFilePath();
            Files.deleteIfExists(Paths.get(outputFilePath));
        }
        catch(NoSuchFileException e)
        {
            logger.error("No such file/directory exists");
        }
        catch(DirectoryNotEmptyException e)
        {
            logger.error("Directory is not empty.");
        }
        catch(IOException e)
        {
            logger.error("Invalid permissions.");
        }

        logger.error("Deletion successful.");
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        FileDownloader that = (FileDownloader) o;

        return fileToDownload != null ? fileToDownload.equals(that.fileToDownload) : that.fileToDownload == null;

    }

    @Override
    public int hashCode() {
        return fileToDownload != null ? fileToDownload.hashCode() : 0;
    }
}
