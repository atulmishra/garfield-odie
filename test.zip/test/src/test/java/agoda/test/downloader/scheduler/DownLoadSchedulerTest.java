package agoda.test.downloader.scheduler;

import agoda.test.downloader.FileDownloader;
import agoda.test.downloader.FileDownloaderFactory;
import agoda.test.downloader.converter.UrlsToFileCreator;
import agoda.test.exception.FileUrlValidationException;
import agoda.test.model.FileToDownload;
import agoda.test.model.FileDownloadResponse;
import agoda.test.model.StatusCode;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.MockitoAnnotations;
import org.mockito.Spy;
import org.mockito.junit.MockitoJUnitRunner;

import java.util.HashSet;
import java.util.Set;

@RunWith(MockitoJUnitRunner.class)
public class DownLoadSchedulerTest {

    @Spy
    DownLoadScheduler downLoadScheduler;

    @Spy
    UrlsToFileCreator urlsToFileCreator;

    @Spy
    FileDownloaderFactory fileDownloaderFactory;


    public DownLoadSchedulerTest() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void testScheduleFilesDataDownLoad() throws Exception {
        //Can change this file url to some inside file from project as well. Just given to check the downloading part is working and
        // downloading this file from net to 'downloaded' folder in project
        String fileUrls="http://www.act.org/content/dam/act/unsecured/documents/relaunch.pdf";
        Set<FileToDownload> filesToDownload=urlsToFileCreator.createFiles(fileUrls);
        Set<FileDownloader> fileDownloaders=getFileDownLoaders(filesToDownload);
        FileDownloadResponse response=downLoadScheduler.scheduleFilesDataDownLoad(fileDownloaders);
        Assert.assertNotNull(response);
        Assert.assertEquals(response.getStatusCode(), StatusCode.SUCCESS.getStatusCode());
        for (FileDownloader fileDownloader:fileDownloaders){
            fileDownloader.cleanPartialDataIfWritten();
        }
    }

    private Set<FileDownloader>  getFileDownLoaders(Set<FileToDownload> fileToDownloads) throws FileUrlValidationException {
        Set<FileDownloader> fileDownloaders = new HashSet<>();
        for(FileToDownload fileToDownload:fileToDownloads){
            FileDownloader fileDownloader = fileDownloaderFactory.getFileDownloader(fileToDownload);
            if(fileDownloader == null){
                throw new FileUrlValidationException("Could not process/download data, no valid downloading protocol");
            }
            fileDownloaders.add(fileDownloader);
        }
        return fileDownloaders;
    }

}