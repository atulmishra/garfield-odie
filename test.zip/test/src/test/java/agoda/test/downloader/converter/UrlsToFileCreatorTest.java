package agoda.test.downloader.converter;

import agoda.test.downloader.scheduler.DownLoadScheduler;
import agoda.test.exception.FileUrlValidationException;
import agoda.test.model.FileToDownload;
import agoda.test.model.ProtocolType;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.MockitoAnnotations;
import org.mockito.Spy;
import org.mockito.junit.MockitoJUnitRunner;

import java.util.Set;

import static org.junit.Assert.*;

@RunWith(MockitoJUnitRunner.class)
public class UrlsToFileCreatorTest {

    @Spy
    UrlsToFileCreator urlsToFileCreator;

    public UrlsToFileCreatorTest() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void createFilesTodownloadFromFileUrls() throws Exception {

        String fileUrls="sftp://test.com";
        Set<FileToDownload> fileToDownloadSet=urlsToFileCreator.createFiles(fileUrls);
        Assert.assertNotNull(fileToDownloadSet);
        Assert.assertEquals(fileToDownloadSet.size(),1);
        for(FileToDownload fileToDownload:fileToDownloadSet){
            ProtocolType createdFileProtocolType=fileToDownload.getProtocolType();
            Assert.assertTrue(createdFileProtocolType.name().equalsIgnoreCase("sftp"));
            Assert.assertTrue(fileToDownload.getOutputFilePath().equalsIgnoreCase("downloaded/test.com"));
            Assert.assertTrue(fileToDownload.getFileUrlToBeDownloaded().equalsIgnoreCase("sftp://test.com"));
        }

    }

    @Test
    public void createFilesTodownloadFromFileUrlsPipeSeparated() throws Exception {

        String fileUrls="sftp://test.com|http://test2.com/test";
        Set<FileToDownload> fileToDownloadSet=urlsToFileCreator.createFiles(fileUrls);
        Assert.assertNotNull(fileToDownloadSet);
        Assert.assertEquals(fileToDownloadSet.size(),2);
        for(FileToDownload fileToDownload:fileToDownloadSet){
            ProtocolType createdFileProtocolType=fileToDownload.getProtocolType();
            if(createdFileProtocolType.name().equals(ProtocolType.SFTP.name())){
                Assert.assertTrue(createdFileProtocolType.name().equalsIgnoreCase("sftp"));
                Assert.assertTrue(fileToDownload.getOutputFilePath().equalsIgnoreCase("downloaded/test.com"));
                Assert.assertTrue(fileToDownload.getFileUrlToBeDownloaded().equalsIgnoreCase("sftp://test.com"));
            }
            else if(createdFileProtocolType.name().equals(ProtocolType.HTTP.name())){
                Assert.assertTrue(createdFileProtocolType.name().equalsIgnoreCase("http"));
                Assert.assertTrue(fileToDownload.getOutputFilePath().equalsIgnoreCase("downloaded/test2.com/test"));
                Assert.assertTrue(fileToDownload.getFileUrlToBeDownloaded().equalsIgnoreCase("http://test2.com/test"));
            }

        }

    }

    @Test(expected = FileUrlValidationException.class)
    public void createFilesTodownloadFromFileUrlsIncorrectProtocol() throws Exception {

        String fileUrls="sftp://test.com|htttpp://test2.com/test";
        Set<FileToDownload> fileToDownloadSet=urlsToFileCreator.createFiles(fileUrls);
        Assert.assertNotNull(fileToDownloadSet);
        Assert.assertEquals(fileToDownloadSet.size(),2);
        for(FileToDownload fileToDownload:fileToDownloadSet){
            ProtocolType createdFileProtocolType=fileToDownload.getProtocolType();
            if(createdFileProtocolType.name().equals(ProtocolType.SFTP.name())){
                Assert.assertTrue(createdFileProtocolType.name().equalsIgnoreCase("sftp"));
                Assert.assertTrue(fileToDownload.getOutputFilePath().equalsIgnoreCase("downloaded/test.com"));
                Assert.assertTrue(fileToDownload.getFileUrlToBeDownloaded().equalsIgnoreCase("sftp://test.com"));
            }
            else if(createdFileProtocolType.name().equals(ProtocolType.HTTP.name())){
                Assert.assertTrue(createdFileProtocolType.name().equalsIgnoreCase("http"));
                Assert.assertTrue(fileToDownload.getOutputFilePath().equalsIgnoreCase("downloaded/test2.com/test"));
                Assert.assertTrue(fileToDownload.getFileUrlToBeDownloaded().equalsIgnoreCase("http://test2.com/test"));
            }

        }

    }

    @Test(expected = FileUrlValidationException.class)
    public void createFilesTodownloadFromFileUrlsIncorrectUrls() throws Exception {
        String fileUrls="sftp://";
        Set<FileToDownload> fileToDownloadSet=urlsToFileCreator.createFiles(fileUrls);
        Assert.assertNotNull(fileToDownloadSet);
        Assert.assertEquals(fileToDownloadSet.size(),1);
    }

}