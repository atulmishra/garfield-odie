package agoda.test.downloader;

import agoda.test.downloader.converter.UrlsToFileCreator;
import agoda.test.downloader.scheduler.DownLoadScheduler;
import agoda.test.model.FileToDownload;
import agoda.test.model.ProtocolType;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.HashSet;
import java.util.Set;

import static org.junit.Assert.*;
import static org.mockito.ArgumentMatchers.anyObject;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class DataDownLoaderTest {

    public DataDownLoaderTest() {
        MockitoAnnotations.initMocks(this);
    }

    @InjectMocks
    DataDownLoader dataDownLoader;

    @Mock
    UrlsToFileCreator urlsToFileCreator;

    @Mock
    FileDownloaderFactory fileDownloaderFactory;

    @Mock
    DownLoadScheduler downLoadScheduler;



    @Test
    public void downloadFilesContentFromUrls() throws Exception {
        String fileToDownloadUrls="http://www.act.org/content/dam/act/unsecured/documents/relaunch.pdf|http://www.act.org/content/dam/act/unsecured/documents/relaunch.pdf";
        Set<FileToDownload> fileToDownloads =new HashSet<>();
        FileToDownload fileToDownload= new FileToDownload("http://test.com", ProtocolType.HTTP,"downloaded/test.com");
        fileToDownloads.add(fileToDownload);
        when(urlsToFileCreator.createFiles(fileToDownloadUrls)).thenReturn(fileToDownloads);
        when(fileDownloaderFactory.getFileDownloader(fileToDownload)).thenReturn(new HTTPFileDataDownloader(fileToDownload));
        dataDownLoader.downloadFilesContentFromUrls(fileToDownloadUrls);
        verify(urlsToFileCreator, times(1)).createFiles(fileToDownloadUrls);
        verify(fileDownloaderFactory, times(1)).getFileDownloader(fileToDownload);
        verify(downLoadScheduler, times(1)).scheduleFilesDataDownLoad(anyObject());
    }

}