package agoda.test.downloader;

import agoda.test.model.FileToDownload;
import agoda.test.model.ProtocolType;
import org.junit.Assert;
import org.junit.Test;
import org.mockito.MockitoAnnotations;
import org.mockito.Spy;

import static org.junit.Assert.*;


public class FileDownloaderFactoryTest {

    @Spy
    FileDownloaderFactory fileDownloaderFactory;

    public FileDownloaderFactoryTest() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void getFileDownloaderHttp() throws Exception {
        FileToDownload fileToDownload=new FileToDownload("http://test.com", ProtocolType.HTTP,"downloaded/test.com");
        FileDownloader httpFileDataDownloader=fileDownloaderFactory.getFileDownloader(fileToDownload);
        Assert.assertNotNull(httpFileDataDownloader);
        Assert.assertEquals(httpFileDataDownloader.getFileToDownLoad().getProtocolType(),ProtocolType.HTTP);
    }

    @Test
    public void getFileDownloaderFtp() throws Exception {
        FileToDownload fileToDownload=new FileToDownload("ftp://test.com", ProtocolType.FTP,"downloaded/test.com");
        FileDownloader ftpFileDataDownloader=fileDownloaderFactory.getFileDownloader(fileToDownload);
        Assert.assertNotNull(ftpFileDataDownloader);
        Assert.assertEquals(ftpFileDataDownloader.getFileToDownLoad().getProtocolType(),ProtocolType.FTP);
    }

    @Test
    public void getFileDownloaderSftp() throws Exception {
        FileToDownload fileToDownload=new FileToDownload("sftp://test.com", ProtocolType.SFTP,"downloaded/test.com");
        FileDownloader sftpFileDataDownloader=fileDownloaderFactory.getFileDownloader(fileToDownload);
        Assert.assertNotNull(sftpFileDataDownloader);
        Assert.assertEquals(sftpFileDataDownloader.getFileToDownLoad().getProtocolType(),ProtocolType.SFTP);
    }

}