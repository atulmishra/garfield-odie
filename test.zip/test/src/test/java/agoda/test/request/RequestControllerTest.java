package agoda.test.request;

import agoda.test.downloader.DataDownLoader;
import agoda.test.model.FilesDownloadRequest;
import agoda.test.model.FileDownloadResponse;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.skyscreamer.jsonassert.JSONAssert;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import static org.mockito.ArgumentMatchers.anyString;

@RunWith(SpringRunner.class)
@WebMvcTest(value = RequestController.class, secure = false)
public class RequestControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private DataDownLoader dataDownLoader;

    FilesDownloadRequest filesDownloadRequest = new FilesDownloadRequest();

    String exampleRequestJson = "{\"fileDownloadedUrls\": \"http://www.act.org/content/dam/act/unsecured/documents/relaunch.pdf|http://www.act.org/content/dam/act/unsecured/documents/relaunch.pdf\"}";


    @Test
    public void downloadFiles() throws Exception {
        filesDownloadRequest.setFileDownloadedUrls("http://test.com/");
        FileDownloadResponse fileDownloadResponse = new FileDownloadResponse();
        fileDownloadResponse.setMessageString("SUCCESS");
        fileDownloadResponse.setStatusCode(1);
        Mockito.when(
                dataDownLoader.downloadFilesContentFromUrls(anyString())).thenReturn(fileDownloadResponse);

        RequestBuilder requestBuilder = MockMvcRequestBuilders.post(
                "http://localhost:8080/").accept(MediaType.APPLICATION_JSON)
                .contentType(MediaType.APPLICATION_JSON_VALUE).content(exampleRequestJson);

        MvcResult result = mockMvc.perform(requestBuilder).andReturn();

        System.out.println(result.getResponse());
        String expected = "{\"messageString\": SUCCESS,\"statusCode\": 1}";
        JSONAssert.assertEquals(expected, result.getResponse()
                .getContentAsString(), false);

    }

}